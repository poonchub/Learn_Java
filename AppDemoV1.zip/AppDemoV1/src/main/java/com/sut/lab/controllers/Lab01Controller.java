package com.sut.lab.controllers;

import com.sut.lab.entities.Book;
import com.sut.lab.entities.BookType;
import com.sut.lab.repositories.BookTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/lab")
public class Lab01Controller {

    @Autowired
    private BookTypeRepository bookTypeRepository;

//    http://localhost:8080/lab/input2
// http://localhost:8080/lab/input?a=1&b=2
    @GetMapping("/input")
    public Integer readInput(@RequestParam("a") Integer a,@RequestParam("b") Integer b){

        System.out.println(a);
        System.out.println(b);






        return a+b;
    }

//  http://localhost:8080/lab/input
    @GetMapping("/input2")
    public String readInput2(){

        return "test lab";
    }

    @PostMapping("/save-book-type")
    public String saveBook(@RequestBody BookType bookType){


        bookTypeRepository.save(bookType);

        return "save success";
    }

    @GetMapping("/find-all")
    public List<BookType> findAll(){

        List<BookType> listBookType = bookTypeRepository.findAll();

        return listBookType;
    }


}
