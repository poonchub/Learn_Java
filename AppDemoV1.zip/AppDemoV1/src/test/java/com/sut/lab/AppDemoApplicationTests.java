package com.sut.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
